/*
 * This is a  sample program for CISC4080 Computer Algorithms
 *
 * Henry Han
 * Last update: Nov 07, 2013
 
 * NOTE: This program makes use of the ASCII subset of UNICODE.
 * Since the most common printable English characters have
 * UNICODE values 32-126, the shift occurs through this
 * entire range.
 *
 */

import java.util.Scanner;

public class ShiftCipher
{
    public static void main(String[] args)
    {
        final int ASCII_MIN = 32;
        final int ASCII_MAX = 126;
        final int ADJUST = 95;
        
        //ADJUST is derived from the fact that there are 95 characters
        //(including blank space ASCII=32) in the printable range.
        //KEY % 95 represents shifts from 0 to 94
        //KEY can be any integer number
        
        int key, temp;
        String plainText, cipherText = "";
        Scanner keyboard = new Scanner(System.in);
    
        System.out.print("Enter the message you want to encrypt:\n");
        plainText = keyboard.nextLine();
        
        System.out.print("\nEnter an encryption key: ");
        key = keyboard.nextInt() % ADJUST;
        
        //plainText characters are right shifted by key:
        for (int i = 0; i < plainText.length(); i++)
        {
            //Do you know why I can skip mod here?
            temp = (int)plainText.charAt(i) + key; 
            if (temp > ASCII_MAX)
            {
                temp -= ADJUST;
            }
            cipherText += (char)temp;
        }
        
        System.out.print("\nYour encrypted message is:\n");
        System.out.print(cipherText);
        
        //cipherText characters are left shifted by key:
        plainText = "";
        for (int i = 0; i < cipherText.length(); i++)
        {
            temp = (int)cipherText.charAt(i) - key;
            if (temp < ASCII_MIN)
            {
                temp += ADJUST;
            }
            plainText += (char)temp;
        }
        System.out.print("\n\nYour decrypted message is:\n");
        System.out.println(plainText);
    }
}    
