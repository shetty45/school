/*
 shiftCipher.cpp
 * Author: Henry Han
 * Note: this is a sample program for CISC4080
 * Last update:  Nov 07, 2013
 *
 *
 */

#include "shiftCipher.hpp"
#include <cstring>

using namespace std;

shiftCipher::shiftCipher(string s0, int key0){
	s=s0;
	key=key0;
}

void shiftCipher::setCipher(string s0){
	s=s0;
}

void shiftCipher::setKey(int key0){
    key=key0;
}

int * shiftCipher::stringToInt(){
    int * intArray;
	intArray=new int[s.length()];
    for(int i=0; i<s.length(); i++)
	    intArray[i]=(int) s[i];
	return intArray;
}
	
int * shiftCipher::encryptIntArray(int *intArray){
    
	int *shiftArray=new int[s.length()];
	for(int i=0; i<s.length(); i++){
	   shiftArray[i]=(intArray[i]+key)%95+32;

        }
	return shiftArray;
}

void shiftCipher::encryptString(int *shiftArray){
    string temp="";
	for(int i=0; i<s.length(); i++){
	    char t=(char)shiftArray[i];
		temp=temp+string(1,t);
	}
    s=temp;
}

void  shiftCipher::decrypt(int *shiftArray){
    string temp="";
     for(int i=0; i<s.length(); i++){
	    int j=0;
	    while(shiftArray[i]-32+95*j-key<32) j++;		  
	    shiftArray[i]=shiftArray[i]-32+95*j-key;  
        char t= (char) shiftArray[i];
        temp = temp + string(1,t);
     }
  
    s=temp;
}


void shiftCipher::print(){ 
    cout<<s<<endl;
	cout<<endl;
}


int main(int argc, char** argv) {
  
   //Enter plain text and key
        string plainText="";	
        cout<<"Enter your message: "<<endl;
	getline(cin,plainText);
	int k;
	cout<<endl;
        
	cout<<"Enter your shift key: "<<endl;
	cin>>k;
	cout<<endl;
   
   //Build a shift cipher	
        shiftCipher A=shiftCipher(plainText,k);
	int n= plainText.length();
	int *a=new int[n];
	a=A.stringToInt();
	
	int *b=new int[n];
	b=A.encryptIntArray(a);
 	        
	A.encryptString(b);
	cout<<"Encrypted message: "<<endl;
	A.print();
	
	A.decrypt(b);
	cout<<"Decryped message: "<<endl;
	A.print();
	
	return 0;
}


