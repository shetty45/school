/* 
 * File:   shiftCipher.hpp
 * Author: Henry Han
 *
 * Updated on November 7, 2013, 6:35 PM
 */

#ifndef SHIFTCIPHER_HPP
#define	SHIFTCIPHER_HPP


#include <iostream>
#include <string>

using namespace std;

class shiftCipher{
		
	public:
	// constructors
	    shiftCipher(){
	        s="";
	        key=0;
        }
            
        shiftCipher(string s0, int key0);
	
   // setting method
	   void setCipher(string s0);
	   void setKey(int key0);
	// shift string to integer array
	    int * stringToInt();
	// encryption
	    int * encryptIntArray(int *);
            void  encryptString(int *);
	// decryption
	    void decrypt( int*); 
	// print
	    void print();
  private:
      string s;
      int key;
      

};


#endif	/* SHIFTCIPHER_HPP */

